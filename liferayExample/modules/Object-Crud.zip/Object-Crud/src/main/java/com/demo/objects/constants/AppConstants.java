package com.demo.objects.constants;

public class AppConstants {

	public static final String AUTHORIZATION_HEADER = "Authorization";
}
