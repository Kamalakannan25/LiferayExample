package com.demo.objects.constants;

/**
 * @author Suchismita
 */
public class ObjectCrudPortletKeys {

	public static final String OBJECTCRUD =
		"com_demo_objects_ObjectCrudPortlet";

}